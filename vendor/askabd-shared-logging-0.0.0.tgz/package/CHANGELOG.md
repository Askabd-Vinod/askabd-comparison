# @askabd/shared-logging

All notable changes are documented here, following Keep a Changelog.

## Unreleased

### Added

- Initial package scaffold.
