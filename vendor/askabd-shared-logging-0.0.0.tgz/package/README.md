# @askabd/shared-logging

Layer **L4**. Internal dependencies: `@askabd/shared-utilities` (L0).

## Purpose

Structured logging wrapper around [Pino](https://github.com/pinojs/pino) that
enforces mandatory base fields (service, environment, version), provides
correlation context bindings, and automatically redacts sensitive data from
log output. Gives every AskABD service a consistent, machine-parseable log
format without coupling to a specific transport or aggregation provider.

## When to use this

- You need structured JSON logging in any AskABD service.
- You want correlation IDs (trace/span/request) automatically attached to log
  entries within a request scope.
- You need automatic redaction of sensitive fields (passwords, tokens, secrets).
- You want consistent base metadata (service name, version, environment) in
  every log line.

## When NOT to use this

- **Business logic logging**: If you need domain-specific event emission, use
  `@askabd/shared-events` instead.
- **Metrics / counters**: Use a metrics library (Prometheus, OpenTelemetry metrics).
  This package is for textual log entries only.
- **Transport configuration**: This package does not own where logs go. Configure
  transports via Pino options or infrastructure-level log routing (e.g., Docker
  log drivers, CloudWatch agent).
- **Direct Pino usage without base fields**: If you explicitly don't want mandatory
  service metadata, use Pino directly.

## Install

```bash
npm install @askabd/shared-logging
# pino is a peer dependency — install it if not already present
npm install pino
```

## Quickstart

```typescript
import { createLogger, withContext } from '@askabd/shared-logging';

const logger = createLogger({
  service: 'identity-api',
  environment: 'production',
  version: '1.2.3',
});

// Basic logging — base fields automatically included
logger.info('Server started');
logger.warn({ port: 3000 }, 'Listening on port');

// Bind correlation context for a request scope
const requestLogger = withContext(logger, {
  correlationId: 'abc-123',
  userId: 'user-456',
  requestId: 'req-789',
});

requestLogger.info('Processing request');
// Output: {"level":30,"time":...,"service":"identity-api","environment":"production","version":"1.2.3","correlationId":"abc-123","userId":"user-456","requestId":"req-789","msg":"Processing request"}
```

## Public API

| Export                 | Type         | Description                                                           |
| ---------------------- | ------------ | --------------------------------------------------------------------- |
| `createLogger`         | Function     | Creates a configured Pino logger with base fields and redaction       |
| `LogLevel`             | Const object | `{ TRACE, DEBUG, INFO, WARN, ERROR, FATAL }`                          |
| `LogLevel`             | Type         | Union: `'trace' \| 'debug' \| 'info' \| 'warn' \| 'error' \| 'fatal'` |
| `LoggerConfig`         | Interface    | Configuration for `createLogger`                                      |
| `withContext`          | Function     | Creates a child logger with correlation context bindings              |
| `LogContext`           | Interface    | Typed context fields (correlationId, traceId, etc.)                   |
| `redact`               | Function     | Merges default + custom redaction paths into Pino format              |
| `DEFAULT_REDACT_PATHS` | Const array  | Always-redacted field paths                                           |
| `RedactConfig`         | Interface    | Pino-compatible redact configuration shape                            |

## Testing subpath

Test utilities are exported from `@askabd/shared-logging/testing` to keep them
out of the production bundle:

```typescript
import { createTestLogger } from '@askabd/shared-logging/testing';

const logger = createTestLogger();
logger.info({ userId: '123' }, 'test event');

expect(logger.entries).toHaveLength(1);
expect(logger.entries[0].msg).toBe('test event');
expect(logger.entries[0].userId).toBe('123');

logger.clear(); // reset between tests
```

| Export             | Type      | Description                                |
| ------------------ | --------- | ------------------------------------------ |
| `createTestLogger` | Function  | In-memory logger capturing entries as JSON |
| `TestLogger`       | Interface | Logger with `entries` array and `clear()`  |
| `LogEntry`         | Interface | Shape of a captured log entry              |

## Architecture notes

- **No transport coupling**: The logger factory creates a vanilla Pino instance.
  Transports are configured by the consumer or infrastructure layer.
- **Extensible config**: `LoggerConfig` is designed to accept future options
  (custom serializers, transport targets, provider hooks) without breaking
  existing consumers.
- **Redaction by default**: Sensitive fields are always redacted. Consumers can
  add paths but cannot remove the defaults.
- **Pino as peer**: Keeps a single Pino instance per service. No version
  conflicts from transitive deps.

## Dependency rules

This package may import only from layers strictly below L4.
See `docs/governance/dependency-rules.md`.
