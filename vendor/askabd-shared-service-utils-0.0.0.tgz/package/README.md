# @askabd/shared-service-utils

Reusable service-layer utilities for AskABD platform services. Eliminates repetitive try/catch boilerplate in route handlers and service methods.

## Layer

L5 (middleware) — imports from `@askabd/shared-errors` (L1).

## Exports

| Export | Purpose |
|--------|---------|
| `safeQuery` | Observable read with fallback (never throws to caller) |
| `safeWrite` | Wraps throwing operations into a Result |
| `withErrorMap` | Maps error codes to custom ServiceError responses |
| `sendResult` | Converts a Result into an HTTP response |

## Usage

```ts
import { safeQuery, safeWrite, sendResult, withErrorMap } from '@askabd/shared-service-utils';

// Read with fallback (GET endpoints)
const items = await safeQuery(() => prisma.item.findMany(), []);

// Write with default error mapping
const result = await safeWrite(() => prisma.category.create({ data }), myMapper);

// Write with code-specific error messages
const result = await withErrorMap(
  () => prisma.category.create({ data }),
  { P2002: { category: 'conflict', code: 'DUPLICATE', message: 'Already exists', statusCode: 409 } }
);

// Convert Result to HTTP response
sendResult(reply, result, 201);
```

## When NOT to use this package

- For business rule validation — use `@askabd/shared-validation`
- For error classification/creation — use `@askabd/shared-errors`
- For Result type combinators — use `@askabd/shared-result`
- For database connection management — that's application-level
- For Fastify plugin registration — use `@askabd/shared-middleware`
