# @askabd/shared-service-utils

## 0.0.0

### Added

- `safeQuery` — observable async read with fallback and optional logging
- `safeWrite` — wraps throwing operations into ServiceResult with custom error mapper
- `withErrorMap` — maps error codes (e.g., Prisma P2002) to custom ServiceError
- `sendResult` — converts ServiceResult to HTTP response (Fastify-compatible)
