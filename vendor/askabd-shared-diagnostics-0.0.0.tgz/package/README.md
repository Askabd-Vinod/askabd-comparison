# @askabd/shared-diagnostics

AskABD multi-audience diagnostics engine (Layer 4).
