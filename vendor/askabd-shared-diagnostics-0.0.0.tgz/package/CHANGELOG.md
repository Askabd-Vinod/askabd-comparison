# @askabd/shared-diagnostics

## 0.0.0
- Initial extraction
