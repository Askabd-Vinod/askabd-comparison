# @askabd/shared-validation

Validation utilities for the AskABD shared platform. Provides schema-based validation with
Result-typed outcomes, reusable rule factories, common schemas, input sanitization, and DTO
base utilities.

Layer 2 (L2) — depends on `@askabd/shared-utilities`, `@askabd/shared-result`, and
`@askabd/shared-errors`.

## Install

```bash
npm install @askabd/shared-validation
```

Zod (`^3.25.0`) is a **peer dependency** — install it alongside this package in your service:

```bash
npm install zod
```

## Quickstart

```typescript
import { z } from 'zod';
import {
  validate,
  validateMany,
  sanitize,
  createDTOSchema,
  createBaseDTO,
} from '@askabd/shared-validation';

// 1. Validate unknown input against a schema
const UserSchema = z.object({ name: z.string(), age: z.number() });
const result = validate(UserSchema, { name: 'Alice', age: 30 });

if (result._tag === 'Ok') {
  console.log(result.value); // { name: 'Alice', age: 30 }
} else {
  console.log(result.error.message); // Validation failed...
}

// 2. Sanitize user input
const clean = sanitize('<script>alert("xss")</script>Hello');
// 'alert("xss")Hello'

// 3. Create a DTO with base fields
const TaskDTOSchema = createDTOSchema({ title: z.string() });
const TaskDTO = createBaseDTO(TaskDTOSchema);
const taskResult = TaskDTO.fromRaw({
  id: '...',
  createdAt: '...',
  updatedAt: '...',
  title: 'Do stuff',
});
```

## When NOT to use this package

- **Business-level domain validation logic.** This package provides infrastructure-level
  validation. Domain rules like "a workflow can have at most 5 steps" belong in the owning
  service, not here.
- **Runtime type checking at trust boundaries with custom formats.** If you need format
  validation beyond what Zod provides (e.g. ASN.1, protobuf), use a dedicated parser.
- **Form-level validation in a frontend.** This package targets server-side Node.js. For
  client-side form validation, use Zod directly with your form library.

## Public API

| Export                 | Module   | Description                                              |
| ---------------------- | -------- | -------------------------------------------------------- |
| `validate<T>`          | validate | Parse unknown input, return `Result<T, ValidationError>` |
| `validateMany<T>`      | validate | Parse array of inputs, return first error or all values  |
| `FieldError`           | validate | Interface describing a single field failure              |
| `minLength`            | rules    | Factory: `z.string().min(n)`                             |
| `maxLength`            | rules    | Factory: `z.string().max(n)`                             |
| `pattern`              | rules    | Factory: `z.string().regex(re)`                          |
| `range`                | rules    | Factory: `z.number().min(a).max(b)`                      |
| `oneOf`                | rules    | Factory: `z.enum(values)`                                |
| `custom`               | rules    | Factory: `z.custom(fn, message)`                         |
| `UuidSchema`           | schemas  | `z.string().uuid()`                                      |
| `EmailSchema`          | schemas  | `z.string().email()`                                     |
| `PhoneNumberSchema`    | schemas  | E.164 phone regex                                        |
| `ISOTimestampSchema`   | schemas  | `z.string().datetime()`                                  |
| `NonEmptyStringSchema` | schemas  | `z.string().min(1)`                                      |
| `UrlSchema`            | schemas  | `z.string().url()`                                       |
| `sanitize`             | sanitize | Strip HTML tags, trim whitespace                         |
| `createDTOSchema`      | base-dto | Merge base fields with domain shape                      |
| `createBaseDTO`        | base-dto | Create `{ fromRaw, toJSON }` from schema                 |
| `BaseDTO<T>`           | base-dto | Type interface for DTO wrappers                          |

## Architecture Notes

### Zod as a peer dependency

Zod is declared as a `peerDependency` rather than a direct `dependency`. This ensures
consuming services never bundle two separate Zod instances — which would break schema
interoperability and increase bundle size. Services must install Zod `^3.25.0` alongside
this package.

### Result pattern

All validation functions return `Result<T, ValidationError>` instead of throwing. This makes
failure a first-class value in the type system, forcing callers to handle both outcomes
explicitly. `ValidationError` is imported from `@askabd/shared-errors` and carries structured
`FieldError[]` context for downstream consumption.

### Layer constraints

As an L2 package, `@askabd/shared-validation` may only import from L0 (`shared-utilities`)
and L1 (`shared-result`, `shared-errors`). It must never import from L2+ packages.
