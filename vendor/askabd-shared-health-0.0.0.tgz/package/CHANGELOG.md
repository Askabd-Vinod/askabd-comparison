# @askabd/shared-health

## 0.0.0
- Initial extraction from askabd-comparison
