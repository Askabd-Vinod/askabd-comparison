# @askabd/shared-health

Multi-dimensional platform health engine. Layer L4.
