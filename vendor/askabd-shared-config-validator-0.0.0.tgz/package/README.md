# @askabd/shared-config-validator

Startup configuration validation engine. Validates external dependencies and returns human-readable diagnostics.

## Layer
L4 (configuration)

## When NOT to use
- Runtime health checks → use @askabd/shared-health
- Request validation → use @askabd/shared-validation
