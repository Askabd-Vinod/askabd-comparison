# @askabd/shared-config-validator

## 0.0.0
- Initial extraction from askabd-comparison platform
