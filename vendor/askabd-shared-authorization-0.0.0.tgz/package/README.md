# @askabd/shared-authorization
RBAC authorization engine. Layer L4. No framework coupling.
