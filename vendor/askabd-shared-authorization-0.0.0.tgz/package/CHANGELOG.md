# @askabd/shared-authorization

## 0.0.0
- Initial extraction from askabd-comparison
