# @askabd/shared-utilities

Layer **L0**. Internal dependencies: none.

## Purpose

Zero-dependency foundation layer providing common utility functions consumed by
every other shared package and every AskABD service. Contains UUID generation,
time arithmetic, object/string manipulation, type guards, a leak-proof secret
wrapper, and an exponential-backoff retry mechanism.

## When to use this

- Generate or validate UUIDs across the platform.
- Compare, create, or adjust ISO 8601 UTC timestamps.
- Deep-freeze configuration objects.
- Safely omit or pick keys from objects.
- Slugify user input for URL-safe identifiers.
- Truncate display strings.
- Mask sensitive values in logs or UI.
- Assert exhaustiveness in discriminated union switches.
- Wrap credentials, tokens, or keys so they cannot leak via logging or serialization.
- Retry transient failures with exponential backoff.

## When NOT to use this

- **Business logic**: validation rules, workflow conditions, domain calculations
  belong in the owning service, never here.
- **Error types**: use `@askabd/shared-errors` (L1).
- **Result pattern**: use `@askabd/shared-result` (L1).
- **Schema validation**: use `@askabd/shared-validation` (L2).
- **Configuration loading**: use `@askabd/shared-configuration` (L4).
- **Logging**: use `@askabd/shared-logging` (L4).

## Install

```bash
npm install @askabd/shared-utilities
```

## Quickstart

```typescript
import {
  generateUuid,
  isValidUuid,
  nowISO,
  addDuration,
  isExpired,
  deepFreeze,
  omit,
  pick,
  slugify,
  truncate,
  maskSensitive,
  assertDefined,
  assertNever,
  SecretReference,
  isSecretReference,
  withRetry,
} from '@askabd/shared-utilities';

// UUID
const id = generateUuid();
console.log(isValidUuid(id)); // true

// Time
const now = nowISO(); // '2024-06-15T14:22:03.412Z'
const later = addDuration(now, { hours: 2 });
console.log(isExpired(now)); // false (just created)

// Object
const config = deepFreeze({ db: { port: 5432 } });
const safe = omit({ id: '1', password: 'x' }, ['password']);

// String
const slug = slugify('Hello World!'); // 'hello-world'
const short = truncate('Long text here', 8); // 'Long te…'
const masked = maskSensitive('api-key-12345'); // 'api*******345'

// Secret
const dbPassword = new SecretReference('super-secret');
console.log(dbPassword); // '[REDACTED]'
JSON.stringify({ pw: dbPassword }); // '{"pw":"[REDACTED]"}'
dbPassword.reveal(); // 'super-secret' — the only way

// Retry
const data = await withRetry(() => fetch('/api/data'), {
  maxAttempts: 3,
  baseDelayMs: 200,
  backoffFactor: 2,
});
```

## Public API

| Export                                           | Description                             |
| ------------------------------------------------ | --------------------------------------- |
| `generateUuid()`                                 | Cryptographically secure UUID v4        |
| `isValidUuid(value)`                             | Validates UUID v4 format                |
| `nowISO()`                                       | Current UTC time as ISO 8601            |
| `isExpired(timestamp)`                           | Whether an ISO timestamp is in the past |
| `addDuration(timestamp, duration)`               | Time arithmetic on ISO strings          |
| `deepFreeze(obj)`                                | Recursively freeze an object graph      |
| `omit(obj, keys)`                                | New object without specified keys       |
| `pick(obj, keys)`                                | New object with only specified keys     |
| `slugify(input)`                                 | URL-safe slug from a string             |
| `truncate(input, maxLength)`                     | Truncate with ellipsis                  |
| `maskSensitive(input, visibleChars?, maskChar?)` | Partially mask a string                 |
| `assertDefined(value, message?)`                 | Assert non-null/undefined               |
| `assertNever(value, message?)`                   | Exhaustiveness check                    |
| `SecretReference`                                | Leak-proof secret wrapper class         |
| `isSecretReference(value)`                       | Symbol-brand identity check             |
| `withRetry(operation, options)`                  | Async retry with exponential backoff    |

## Dependency rules

This package has zero dependencies. It may not import from any other shared
package. See `docs/governance/dependency-rules.md`.

## Versioning

Follows semantic versioning. Every public API change requires a changeset:

- **patch**: bug fixes
- **minor**: new exports
- **major**: removals, renames, type narrowings, behavior changes
