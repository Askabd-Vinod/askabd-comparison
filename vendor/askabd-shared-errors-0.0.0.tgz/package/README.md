# @askabd/shared-errors

Layer **L1**. Internal dependencies: `@askabd/shared-utilities`.

## Purpose

<!-- One paragraph. What single concern does this package own? -->

## When to use this

<!-- Concrete situations where a consumer should reach for this package. -->

## When NOT to use this

<!-- Equally important. Point to the correct package instead. -->

## Install

```bash
npm install @askabd/shared-errors
```

## Quickstart

```typescript
// Minimal working example.
```

## Public API

<!-- Every export, with a one-line description. -->

## Dependency rules

This package may import only from layers strictly below L1.
See `docs/governance/dependency-rules.md`.
