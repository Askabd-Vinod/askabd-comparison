# @askabd/shared-monitoring

AskABD metrics collection (Layer 5).
