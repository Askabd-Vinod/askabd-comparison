# @askabd/shared-configuration

Configuration loading, environment detection, and secret handling for the AskABD shared
engineering platform.

Validates environment variables against a Zod schema, returns deeply frozen results via the
`Result` pattern, and provides leak-proof secret wrapping through `SecretReference`.

## Install

```bash
npm install @askabd/shared-configuration
```

### Peer dependencies

These must be installed in your consuming service:

```bash
npm install dotenv@^16 zod@^3.25
```

## Quickstart

```typescript
import { z } from 'zod';
import { loadConfig, secretTransform } from '@askabd/shared-configuration';

const AppConfigSchema = z.object({
  PORT: z.string().transform(Number),
  DATABASE_URL: z.string().url(),
  API_KEY: secretTransform,
});

const result = loadConfig(AppConfigSchema, {
  envFile: '.env',
  prefix: 'APP_',
});

if (result._tag === 'Ok') {
  const config = result.value;
  console.log(config.PORT); // 3000 (number)
  console.log(config.API_KEY.reveal()); // actual secret value
  JSON.stringify(config.API_KEY); // '"[REDACTED]"'
} else {
  console.error(result.error.message);
  // "Configuration validation failed with 2 error(s)"
  console.error(result.error.context);
  // { fields: [{ path: 'PORT', expected: 'Required', received: 'unknown' }, ...] }
}
```

## secretTransform

A Zod transform that wraps string values into `SecretReference` instances, preventing
accidental leakage via logging, serialization, or string interpolation.

```typescript
import { z } from 'zod';
import { secretTransform } from '@askabd/shared-configuration';

const Schema = z.object({
  dbPassword: secretTransform,
  host: z.string(),
});

// After parsing, dbPassword is a SecretReference:
// - .reveal() returns the raw value
// - toString() / toJSON() / console.log all show '[REDACTED]'
```

## Environment helpers

```typescript
import { getEnvironment, isDevelopment, isProduction, isTest } from '@askabd/shared-configuration';

getEnvironment(); // 'production' | 'development' | 'test' | custom
isDevelopment(); // true when NODE_ENV is 'development' or undefined
isProduction(); // true when NODE_ENV is 'production'
isTest(); // true when NODE_ENV is 'test'
```

## When NOT to use this package

- **Business logic configuration**: This package handles infrastructure/service configuration
  (ports, URLs, credentials). Domain-specific settings (feature flags, business rules) belong
  in the owning service.
- **Runtime-changing configuration**: This loads config once at startup and freezes it.
  If you need hot-reload or feature flags, use a dedicated service.
- **Complex secret management**: For vault integration, secret rotation, or lease-based
  access, build a dedicated provider on top of this package rather than extending it.
- **Non-environment sources**: This reads from `process.env` (optionally via `.env` files).
  For JSON/YAML config files, use a different approach.

## Public API

| Export              | Kind      | Description                                                 |
| ------------------- | --------- | ----------------------------------------------------------- |
| `loadConfig`        | function  | Load and validate config from env vars against a Zod schema |
| `LoadConfigOptions` | interface | Options for `loadConfig` (envFile, prefix, overrides, env)  |
| `secretTransform`   | const     | Zod transform wrapping strings into `SecretReference`       |
| `getEnvironment`    | function  | Returns `NODE_ENV` or `'development'`                       |
| `isDevelopment`     | function  | `true` when env is `'development'`                          |
| `isProduction`      | function  | `true` when env is `'production'`                           |
| `isTest`            | function  | `true` when env is `'test'`                                 |
| `SecretReference`   | class     | Re-exported from `@askabd/shared-utilities`                 |
| `isSecretReference` | function  | Re-exported from `@askabd/shared-utilities`                 |

## Architecture notes

- **Fail-fast validation**: All configuration errors are surfaced at startup, not at first use.
  This prevents partial-boot scenarios in production.
- **Aggregate errors**: When multiple fields fail validation, all failures are reported in a
  single `ValidationError` — not just the first. This avoids fix-one-restart-fix-another loops.
- **Frozen results**: The validated config object is deeply frozen via `Object.freeze`.
  Accidental mutation at runtime throws `TypeError` in strict mode, making config drift impossible.
- **Result pattern**: Never throws for expected validation failures. Callers handle the
  `Err` case explicitly — the type system ensures it.
- **Extensible options**: `LoadConfigOptions` is designed to accommodate future provider
  patterns (vault, SSM, etc.) without breaking existing consumers.
- **Layer L4**: Depends on utilities (L0), result (L1), errors (L1), and validation (L2).
  No lateral imports from other L4 packages.
