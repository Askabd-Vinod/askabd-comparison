# @askabd/shared-contracts

Platform-wide type vocabulary for the AskABD shared engineering platform. Layer 3 (L3) package providing infrastructure-level types, schemas, and utility functions shared across all services.

## Purpose

This package defines the **contracts** (types, schemas, and helpers) that all AskABD services use to communicate. It covers authentication context, organization membership, tenant configuration, audit trails, API response envelopes, pagination, sorting, and filtering.

All types are infrastructure-only — no business logic lives here.

## Install

```bash
npm install @askabd/shared-contracts
# zod is a peer dependency
npm install zod
```

## Quickstart

```typescript
import {
  AuthContextSchema,
  hasPermission,
  successResponse,
  parsePaginationParams,
  createAuditEvent,
} from '@askabd/shared-contracts';

// Validate auth claims shape (NOT authentication!)
const claims = AuthContextSchema.parse(tokenPayload);

// Check permissions
if (hasPermission(claims, 'document:read')) {
  // authorized
}

// Parse pagination from query params
const paginationResult = parsePaginationParams(req.query);

// Create a standardized API response
const response = successResponse({ items: [...] });

// Record an audit event
const event = createAuditEvent({
  action: 'create',
  actor: { userId: claims.userId, tenantId: claims.tenantId },
  resource: { type: 'document', id: 'doc-1' },
});
```

## When NOT to use this package

- **Authentication/authorization logic** — this package validates claim _shapes_, not tokens. Token verification, session management, and access control decisions belong in your auth service or middleware.
- **Business domain types** — types specific to a single service (workflow states, identity provider configs) belong in that service.
- **Database schemas** — use `@askabd/shared-database` for persistence contracts.
- **Business rules** — permission lists, role hierarchies, and access policies are business logic. Define them in your service using `definePermissions()`.
- **HTTP framework integration** — use `@askabd/shared-middleware` for request/response handling.

## Public API

| Export                      | Kind     | Description                                          |
| --------------------------- | -------- | ---------------------------------------------------- |
| `AuthContext`               | type     | Authenticated user context shape                     |
| `AuthContextSchema`         | schema   | Zod validator for AuthContext (shape only, NOT auth) |
| `Permission`                | type     | Branded permission string                            |
| `definePermissions`         | function | Creates typed permission sets                        |
| `hasPermission`             | function | Single permission check                              |
| `hasAnyPermission`          | function | Any-of permission check                              |
| `hasAllPermissions`         | function | All-of permission check                              |
| `DefaultMembershipRoles`    | const    | Standard org role constants                          |
| `DefaultMembershipRole`     | type     | Union of default roles                               |
| `Membership<TRole>`         | type     | Generic membership record                            |
| `membershipSchema`          | function | Schema factory for custom roles                      |
| `OrganizationContext`       | type     | Organization descriptor                              |
| `OrganizationContextSchema` | schema   | Zod validator for OrganizationContext                |
| `belongsToOrganization`     | function | Membership org check                                 |
| `TenantContext`             | type     | Tenant descriptor                                    |
| `TenantContextSchema`       | schema   | Zod validator for TenantContext                      |
| `AuditActions`              | const    | Standard audit action constants                      |
| `AuditAction`               | type     | Standard action union                                |
| `AuditActionOf<T>`          | type     | Extensible action union                              |
| `ResourceRef`               | type     | Audit resource reference                             |
| `AuditEvent<T>`             | type     | Structured audit event                               |
| `AuditEventSchema`          | schema   | Zod validator for AuditEvent                         |
| `createAuditEvent`          | function | Factory with auto-generated id/timestamp             |
| `ResponseMeta`              | type     | API response metadata                                |
| `ApiResponse<T>`            | type     | Standard API response envelope                       |
| `ApiResponseSchema`         | schema   | Round-trip validation schema                         |
| `successResponse`           | function | Success envelope factory                             |
| `errorResponse`             | function | Error envelope factory                               |
| `ErrorResponse`             | type     | Re-export from @askabd/shared-errors                 |
| `FieldError`                | type     | Re-export from @askabd/shared-validation             |
| `PaginationParams`          | type     | Validated pagination input                           |
| `PaginatedResponse<T>`      | type     | Paginated response envelope                          |
| `parsePaginationParams`     | function | Validates/coerces pagination input                   |
| `SortDirection`             | const    | Sort direction constants                             |
| `SortParams`                | type     | Sort field + direction                               |
| `parseSortParams`           | function | Parses "field:dir" syntax                            |
| `FilterOperators`           | const    | Standard filter operator constants                   |
| `FilterOperator`            | type     | Filter operator union                                |
| `FilterExpression`          | type     | Filter expression structure                          |
| `FilterExpressionSchema`    | schema   | Zod validator for FilterExpression                   |

## Architecture Notes

- **Layer 3 (L3)** — depends on utilities (L0), result (L1), errors (L1), validation (L2)
- **Zod is a peer dependency** — consumers must install it themselves
- **No hardcoded lists** — permissions, roles, countries, etc. are defined by consumers via factory functions and generics
- **Extensible via generics** — `Membership<TRole>`, `AuditEvent<TAction>`, `AuditActionOf<TExtra>`
- **`AuthContextSchema` validates shape only** — it confirms the object has the right fields. It does NOT verify JWT signatures, check token expiry, or authenticate users
- **No `export enum`** — uses `as const` objects with derived union types for tree-shakeability
- **Result pattern for expected failures** — `parsePaginationParams` returns `Result<T, E>` instead of throwing

## Dependencies

| Package                     | Layer | Purpose                            |
| --------------------------- | ----- | ---------------------------------- |
| `@askabd/shared-utilities`  | L0    | `generateUuid()`, `nowISO()`       |
| `@askabd/shared-result`     | L1    | `Result<T, E>` type                |
| `@askabd/shared-errors`     | L1    | `ValidationError`, `ErrorResponse` |
| `@askabd/shared-validation` | L2    | `validate()`, `FieldError`         |
| `zod`                       | peer  | Runtime schema validation          |
